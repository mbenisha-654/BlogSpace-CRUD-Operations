# BlogSpace — Module 04: CRUD Operations

This is the Module 04 upgrade to the Module 03 BlogSpace project. It uses HTML, CSS, JavaScript and Supabase.

## CRUD features
- **Create:** logged-in users can publish a blog with title, category and content.
- **Read:** all published blogs are retrieved from Supabase and displayed.
- **Update:** the author can edit their own blog.
- **Delete:** the author can delete their own blog after confirmation.
- **Bonus:** search blogs by title/content and filter by category.
- Supabase Auth handles passwords; Row Level Security protects write operations.

## Setup
1. Use the Supabase project you created for Module 03.
2. Open Supabase **SQL Editor → New query**.
3. Run all the SQL in `supabase.sql`. It adds a `category` column if needed and configures the access policies.
4. In `config.js`, enter your Supabase Project URL and anon/public key.
5. Open this folder in VS Code.
6. Run `index.html` with the Live Server extension.

Do not use the Supabase `service_role` secret key in frontend code.

## Test checklist
1. Sign up or log in.
2. Create a blog and confirm it appears in All blogs.
3. Click Edit on your own blog, change the title/content/category and save.
4. Click Delete on your own blog and confirm it disappears.
5. Search for a word and use the category filter.
6. Open Read full blog to test the individual details page.

## GitHub
Create a new repository named `BlogSpace-CRUD-Operations` and upload the extracted project files (not the ZIP file). If you already have a Module 03 repository, you can instead upload these updated files into that repository.

## Deliverables
- GitHub repository URL
- LinkedIn post URL
