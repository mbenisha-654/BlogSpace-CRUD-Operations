const supabaseClient = window.supabase.createClient(window.SUPABASE_URL, window.SUPABASE_ANON_KEY);
const article = document.getElementById("blog-detail");
function escapeHTML(value) {
  return String(value ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));
}
async function loadBlogDetails() {
  const id = new URLSearchParams(location.search).get("id");
  if (!id) { article.innerHTML = "<h2>Blog not found</h2><p>No blog ID was provided.</p>"; return; }
  const { data, error } = await supabaseClient.from("blogs")
    .select("title,content,category,created_at").eq("id", id).single();
  if (error || !data) { article.innerHTML = "<h2>Blog not found</h2><p>This post may have been removed or the database is not configured.</p>"; return; }
  article.innerHTML = `<p class="eyebrow">${escapeHTML(data.category || "Other")} · ${new Date(data.created_at).toLocaleString()}</p>
    <h1>${escapeHTML(data.title)}</h1><div class="article-content">${escapeHTML(data.content).replace(/\n/g,"<br>")}</div>
    <a class="read-link" href="index.html">← Back to all blogs</a>`;
}
loadBlogDetails();
