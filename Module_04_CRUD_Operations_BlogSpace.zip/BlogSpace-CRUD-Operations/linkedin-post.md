🚀 Happy to share my **Module 04 – CRUD Operations** project: BlogSpace!

I extended my blog application using **HTML, CSS, JavaScript and Supabase**.

### Features implemented
- **Create:** publish new blog posts
- **Read:** retrieve and display all blogs from the database
- **Update:** edit existing blog posts
- **Delete:** remove blog posts with confirmation
- **Bonus:** search blogs and filter by category

This project helped me understand how CRUD operations work in a real database-connected application. I also used Supabase Authentication and Row Level Security to protect user actions.

#CRUD #DatabaseIntegration #JavaScript #Supabase #WebDevelopment #LearningByBuilding
