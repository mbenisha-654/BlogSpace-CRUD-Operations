// Supabase -> Project Settings -> API
// Add your Project URL and anon/public key below.
// NEVER use the service_role / secret key in browser code.
window.SUPABASE_URL = "YOUR_SUPABASE_PROJECT_URL";
window.SUPABASE_ANON_KEY = "YOUR_SUPABASE_ANON_PUBLIC_KEY";
