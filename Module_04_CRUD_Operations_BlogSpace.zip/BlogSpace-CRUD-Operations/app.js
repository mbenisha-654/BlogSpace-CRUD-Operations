const supabaseClient = window.supabase.createClient(window.SUPABASE_URL, window.SUPABASE_ANON_KEY);
const $ = (id) => document.getElementById(id);
let editingId = null;
let allBlogs = [];

function message(id, text, error = false) {
  $(id).textContent = text;
  $(id).className = "message " + (error ? "error" : "success");
}
function escapeHTML(value) {
  return String(value ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));
}
async function updateSessionUI() {
  const { data: { session } } = await supabaseClient.auth.getSession();
  const loggedIn = Boolean(session);
  $("auth-section").classList.toggle("hidden", loggedIn);
  $("editor-section").classList.toggle("hidden", !loggedIn);
  $("logout-btn").classList.toggle("hidden", !loggedIn);
  $("user-label").textContent = loggedIn ? session.user.email : "";
}
async function signUp() {
  const email = $("email").value.trim(), password = $("password").value;
  if (!email || password.length < 6) return message("auth-message", "Enter a valid email and password (minimum 6 characters).", true);
  const { error } = await supabaseClient.auth.signUp({ email, password });
  if (error) return message("auth-message", error.message, true);
  message("auth-message", "Account created. Check your email if confirmation is enabled, then log in.");
}
async function logIn() {
  const { error } = await supabaseClient.auth.signInWithPassword({ email: $("email").value.trim(), password: $("password").value });
  if (error) return message("auth-message", error.message, true);
  message("auth-message", "Login successful.");
  await updateSessionUI();
}
async function logOut() {
  await supabaseClient.auth.signOut();
  resetEditor();
  await updateSessionUI();
}
function resetEditor() {
  editingId = null;
  $("blog-form").reset();
  $("form-heading").textContent = "Create a blog post";
  $("save-btn").textContent = "Publish blog";
  $("cancel-edit-btn").classList.add("hidden");
  $("edit-indicator").classList.add("hidden");
}
async function saveBlog(event) {
  event.preventDefault();
  const title = $("blog-title").value.trim();
  const content = $("blog-content").value.trim();
  const category = $("blog-category").value;
  if (!title || !content) return message("editor-message", "Please fill in the title and content.", true);
  const { data: { user } } = await supabaseClient.auth.getUser();
  if (!user) return message("editor-message", "Please log in first.", true);

  let result;
  if (editingId) {
    result = await supabaseClient.from("blogs").update({ title, content, category }).eq("id", editingId).eq("user_id", user.id);
  } else {
    result = await supabaseClient.from("blogs").insert({ title, content, category, user_id: user.id });
  }
  if (result.error) return message("editor-message", result.error.message, true);
  message("editor-message", editingId ? "Blog updated successfully!" : "Blog published successfully!");
  resetEditor();
  await loadBlogs();
}
function startEdit(blog) {
  editingId = blog.id;
  $("blog-title").value = blog.title;
  $("blog-content").value = blog.content;
  $("blog-category").value = blog.category || "Other";
  $("form-heading").textContent = "Update blog post";
  $("save-btn").textContent = "Save changes";
  $("cancel-edit-btn").classList.remove("hidden");
  $("edit-indicator").classList.remove("hidden");
  $("editor-section").scrollIntoView({ behavior: "smooth" });
}
async function deleteBlog(id) {
  if (!confirm("Are you sure you want to delete this blog? This cannot be undone.")) return;
  const { data: { user } } = await supabaseClient.auth.getUser();
  if (!user) return alert("Please log in first.");
  const { error } = await supabaseClient.from("blogs").delete().eq("id", id).eq("user_id", user.id);
  if (error) return alert("Could not delete blog: " + error.message);
  message("editor-message", "Blog deleted successfully.");
  await loadBlogs();
}
function renderBlogs() {
  const query = $("search-input").value.trim().toLowerCase();
  const category = $("category-filter").value;
  const filtered = allBlogs.filter(blog => {
    const matchesText = (blog.title + " " + blog.content).toLowerCase().includes(query);
    const matchesCategory = category === "All" || (blog.category || "Other") === category;
    return matchesText && matchesCategory;
  });
  $("blogs-message").textContent = filtered.length ? `${filtered.length} blog(s) shown` : "No matching blogs found.";
  $("blog-list").innerHTML = filtered.map(blog => `
    <article class="blog-card">
      <div class="card-meta"><span class="category-pill">${escapeHTML(blog.category || "Other")}</span><span>${new Date(blog.created_at).toLocaleDateString()}</span></div>
      <h3>${escapeHTML(blog.title)}</h3>
      <p>${escapeHTML(blog.content.slice(0, 150))}${blog.content.length > 150 ? "…" : ""}</p>
      <a class="read-link" href="details.html?id=${encodeURIComponent(blog.id)}">Read full blog →</a>
      <div class="card-actions">
        <button class="small-button edit-button" data-edit="${escapeHTML(blog.id)}">Edit</button>
        <button class="small-button delete-button" data-delete="${escapeHTML(blog.id)}">Delete</button>
      </div>
    </article>`).join("");
  document.querySelectorAll("[data-edit]").forEach(btn => btn.addEventListener("click", () => {
    const blog = allBlogs.find(item => String(item.id) === btn.dataset.edit);
    if (blog) startEdit(blog);
  }));
  document.querySelectorAll("[data-delete]").forEach(btn => btn.addEventListener("click", () => deleteBlog(btn.dataset.delete)));
}
async function loadBlogs() {
  $("blogs-message").textContent = "Loading blogs...";
  const { data, error } = await supabaseClient.from("blogs")
    .select("id,title,content,category,created_at,user_id")
    .order("created_at", { ascending: false });
  if (error) {
    $("blogs-message").textContent = "Could not load blogs. Run the SQL setup file and check config.js.";
    $("blog-list").innerHTML = "";
    return;
  }
  allBlogs = data || [];
  renderBlogs();
}
$("signup-btn").addEventListener("click", signUp);
$("login-btn").addEventListener("click", logIn);
$("logout-btn").addEventListener("click", logOut);
$("blog-form").addEventListener("submit", saveBlog);
$("cancel-edit-btn").addEventListener("click", resetEditor);
$("refresh-btn").addEventListener("click", loadBlogs);
$("search-input").addEventListener("input", renderBlogs);
$("category-filter").addEventListener("change", renderBlogs);
supabaseClient.auth.onAuthStateChange(() => updateSessionUI());
updateSessionUI();
loadBlogs();
